# Afruvo Voice to Text Converter

**Afruvo** — Voice to Text Converter: Type with your voice, the easy way.

Chrome-এর জন্য (Manifest V3) ভয়েস টাইপিং এক্সটেনশন (বাংলা, English ও Banglish)। যেকোনো টেক্সট বক্সে ক্লিক করুন, কথা বলুন — লেখা কার্সারের জায়গায় বসে যাবে।

## তিনটি মোড

| মোড | আপনি বলবেন | যা লেখা হবে | উদাহরণ |
|---|---|---|---|
| **Bangla** | বাংলা | বাংলা অক্ষরে | `আমি এখন বাসায় যাচ্ছি।` |
| **English** | ইংরেজি | ইংরেজি অক্ষরে | `I am going home now.` |
| **Banglish** | বাংলা | বাংলা কথা, Roman অক্ষরে | `ami ekhon bashay jacchi` |

**Banglish কীভাবে কাজ করে:** Chrome আপনার বাংলা কথা প্রথমে বাংলা লেখায় (`bn-BD`) চেনে, তারপর Afruvo নিজের অফলাইন নিয়মভিত্তিক রূপান্তরকারী (`content/translit.js`) দিয়ে সেটা Roman অক্ষরে বদলায়।
বাংলা শব্দের Roman বানান কোনো স্ট্যান্ডার্ড নেই, তাই এটা **best-effort**: উচ্চারণ-ভিত্তিক (`স/শ → sh`, `ছ → ch`, `চ্ছ → cch`), কিছু শব্দে আপনার পছন্দের বানানের সাথে মিলবে না।

## Windows 11 + Chrome-এ ইনস্টল

1. `Afruvo.zip` এক্সট্র্যাক্ট করুন (যেমন `C:\Afruvo`)।
2. Chrome-এ `chrome://extensions` খুলুন।
3. ডানদিকে উপরে **Developer mode** চালু করুন।
4. **Load unpacked** চাপুন এবং যে ফোল্ডারের ভেতরে সরাসরি `manifest.json` আছে সেটি নির্বাচন করুন।
5. (ঐচ্ছিক) টুলবারে পাজল আইকন থেকে **Afruvo** পিন করুন।

ফাইল বদলালে `chrome://extensions`-এ Afruvo কার্ডের রিলোড বাটন চাপুন, তারপর খোলা ট্যাবগুলো **রিফ্রেশ** করুন।

## ব্যবহার

- **Popup:** টুলবারের Afruvo আইকনে ক্লিক → ভাষা নির্বাচন (Bangla / English / Banglish) → বড় মাইক বাটনে ক্লিক করলে চালু, আবার ক্লিক করলে বন্ধ। নিচে স্ট্যাটাস দেখায় (*Microphone off / Starting… / Listening… / ত্রুটির বার্তা*)।
- **ফ্লোটিং মাইক:** টেক্সট বক্সে ক্লিক করলে পাশে একটি মাইক আসে। ক্লিক = চালু/বন্ধ। চালু থাকলে সবুজ হয়ে স্পন্দিত হয়।
- **মাইক সরানো:** মাইক বাটনটি মাউস চেপে ধরে টেনে স্ক্রিনের যেকোনো জায়গায় (উপরে, নিচে, ডানে, বাঁয়ে) নেওয়া যায়। শুধু ক্লিক করলে আগের মতো চালু/বন্ধ হয়, টানলে হয় না। নতুন জায়গা মনে থাকে (সব সাইটে, ব্রাউজার বন্ধ করে খুললেও)। আবার টেনে অন্য জায়গায় নেওয়া যায়।
- **শর্টকাট `Ctrl + Shift + Y`:** মাইক চালু/বন্ধ। চালু থাকলে টুলবার আইকনে সবুজ **ON** ব্যাজ দেখায়।
- **Light / Dark:** popup-এর উপরের ডানদিকের সূর্য/চাঁদ বাটন।
- মাইক চালু/বন্ধ করার **তিনটি উপায়:** (১) শর্টকাট, (২) popup-এর মাইক বাটন, (৩) টেক্সট বক্সের পাশের মাইক বাটন।
- প্রথমবার মাইক চালু করলে Chrome সাইটের জন্য মাইক্রোফোনের অনুমতি চাইবে — **Allow** দিন।

ভাষা, থিম ও মাইকের জায়গা `chrome.storage.local`-এ সেভ হয়; popup বন্ধ করে আবার খুললে, এমনকি Chrome রিস্টার্ট করলেও, আগের সেটিংস থাকে।

## শর্টকাট `Ctrl + Shift + Y`

`Ctrl+Shift+A` ও `Alt+Shift+A` পরীক্ষায় Chromium নিজে থেকে বসায়নি (Chrome-এর "Search tabs" ইত্যাদির সাথে সংঘর্ষ), আর `Alt+Shift` Windows-এ ভাষা বদলানোর শর্টকাট। তাই `Ctrl+Shift+Y` ব্যবহার করা হয়েছে; পরীক্ষায় এটি Chromium নিজে থেকে বসিয়েছে।

- **টেক্সট বক্সে কার্সার থাকলে** শর্টকাট কাজ করে: এটি পেজের ভেতরে Afruvo নিজে ধরে, তাই কোনো সাইটের নিজস্ব শর্টকাটের আগেই চলে।
- **Chrome-এর বৈশ্বিক শর্টকাট হিসেবে** চেক/বদলাতে: `chrome://extensions/shortcuts` → *Afruvo Voice to Text Converter* → *Turn the microphone on / off*। কোনো সাইটে `Ctrl+Shift+Y` অন্য কাজে ব্যবহৃত হলে সেখান থেকে অন্য কী বসান।
- কোনো টেক্সট বক্স ফোকাসে না থাকলে শর্টকাট কিছু করে না; টুলবার আইকনে এক মুহূর্তের জন্য লাল **!** ও পেজে "Click a text box first" দেখায়।
- মাইক চালু থাকলে টুলবার আইকনে সবুজ **ON** ব্যাজ দেখায়।

## পারমিশন ও গোপনীয়তা

| | কেন |
|---|---|
| `storage` | ভাষা ও থিম মনে রাখতে। কোনো কথা/ট্রান্সক্রিপ্ট সেভ হয় না। |
| `http://*/*`, `https://*/*` (content script) | যেকোনো সাইটের টেক্সট বক্সের পাশে মাইক দেখাতে ও লেখা বসাতে। Chrome একে "read and change your data on all websites" বলে। Afruvo শুধু কোন ফিল্ডে ফোকাস আছে তা দেখে এবং আপনার বলা লেখা বসায়; পেজের কনটেন্ট সংগ্রহ/পাঠায় না। |

Afruvo-র নিজস্ব সার্ভার, অ্যানালিটিক্স বা API key নেই। কথা চেনার কাজ করে Chrome-এর Web Speech API — **Chrome অডিও Google-এর স্পিচ সার্ভিসে পাঠায়, তাই ইন্টারনেট লাগে** এবং প্রক্রিয়াকরণ লোকাল নয়। Banglish রূপান্তর পুরোটাই আপনার ব্রাউজারে হয়।

## সীমাবদ্ধতা

- শুধু Chrome, চালু মাইক্রোফোন ও ইন্টারনেট দরকার; অফলাইনে চলে না।
- `http/https` পেজে কাজ করে; `chrome://` পেজ, Chrome Web Store ও PDF viewer-এ নয়। মাইক্রোফোন শুধু নিরাপদ পেজে (`https://` বা `localhost`) চলে।
- অন্য সাইটের iframe-এ মাইক্রোফোন চালাতে পেজকে `allow="microphone"` দিতে হয়।
- Password, read-only ও disabled ফিল্ড ইচ্ছাকৃতভাবে বাদ।
- Google Docs-এর মতো কাস্টম এডিটরে স্ক্রিপ্টে লেখা বসানো ব্লক হতে পারে; সাধারণ input/textarea/contenteditable চলে।
- বাংলা শনাক্তকরণের মান Chrome-এর স্পিচ সার্ভিসের উপর নির্ভর করে; বাংলা যতিচিহ্ন নিজে থেকে বসে না।

## সমস্যা হলে

- **"Microphone blocked"** → ঠিকানা-বারের তালা আইকন → Microphone: Allow → পেজ রিলোড। আর Windows *Settings → Privacy & security → Microphone*-এ Chrome-কে অনুমতি দিন।
- **মাইক আইকন আসছে না** → আগে টেক্সট বক্সে ক্লিক করুন; এক্সটেনশন ইনস্টল/আপডেটের পর ট্যাব রিফ্রেশ করুন।
- **"Afruvo was updated. Reload this page."** → এক্সটেনশন রিলোডের পর পুরনো ট্যাবটি রিফ্রেশ করুন।
- **ভাষা বদলানো কাজ করছে না** → ট্যাব রিফ্রেশ করুন; চালু অবস্থায় ভাষা বদলালে মাইক নিজে নতুন ভাষায় আবার শুরু হয়।

## ১ মিনিটের টেস্ট চেকলিস্ট (আপনার Chrome-এ)

`https://` সাইটে (যেমন কোনো সার্চ বক্স) করুন:

1. Bangla → `আমি এখন বাসায় যাচ্ছি` বলুন → বাংলা লেখা বসবে।
2. English → `I am going home now` বলুন → ইংরেজি লেখা বসবে।
3. Banglish → বাংলায় `আমি এখন বাসায় যাচ্ছি` বলুন → `ami ekhon bashay jacchi` (প্রায় এরকম) বসবে।
4. popup-এর মাইক বাটন: ক্লিকে চালু (সবুজ, *Listening…*), আবার ক্লিকে বন্ধ (*Microphone off*)।
5. টেক্সট বক্সে কার্সার রেখে `Ctrl+Shift+Y` → চালু; আবার চাপলে বন্ধ।
6. ফ্লোটিং মাইক টেনে অন্য জায়গায় নিন → ক্লিক ছাড়াই সরে যাবে; পেজ রিফ্রেশ করলেও সেখানেই থাকবে।
7. থিম ও ভাষা বদলে popup বন্ধ করে আবার খুলুন → একই থাকবে।

## ফাইল কাঠামো

```
Afruvo/
├─ manifest.json          MV3: popup, service worker, Ctrl+Shift+Y command, content script
├─ background.js          শর্টকাট → সক্রিয় ট্যাবে বার্তা; টুলবারে ON ব্যাজ
├─ content/
│  ├─ content.js          ফ্লোটিং মাইক (টেনে সরানো যায়), স্পিচ রিকগনিশন, লেখা বসানো, শর্টকাট
│  ├─ content.css
│  └─ translit.js         বাংলা → Roman (Banglish) রূপান্তর
├─ popup/                 popup.html / .css / .js, theme-init.js
├─ icons/                 icon16/32/48/128.png (টুলবার ও এক্সটেনশন আইকন, স্পিচ-বাবল)
└─ assets/                afruvo-logo.png (popup হেডার লোগো)
```

---

**English summary:** Afruvo types what you say into any text field on `http(s)` pages. Modes: *Bangla* (Bengali script), *English* (English text), *Banglish* (Bangla speech → Roman letters, e.g. `ami ekhon bashay jacchi`, via an offline rule-based transliterator). The popup has the Afruvo logo, language selector, mic on/off button with live status, light/dark theme; language and theme persist. `Ctrl+Shift+Y` toggles the microphone (also handled in-page). The microphone can be started from the shortcut, the popup button or the floating button; the floating button can be dragged anywhere and remembers its position. Install via `chrome://extensions` → Developer mode → Load unpacked. Speech is processed by Chrome's Web Speech API (internet required); Afruvo stores no transcripts.
