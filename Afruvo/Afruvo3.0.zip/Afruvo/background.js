/*
 * Afruvo – service worker.
 * 1) Receives the Ctrl+Shift+Y command and forwards it to the active tab.
 * 2) Shows a small "ON" badge on the toolbar icon while the microphone is active in a tab.
 * It never reads page content, stores nothing and contacts no server.
 */
'use strict';

var BADGE_ON = '#16a34a';
var BADGE_WARN = '#dc2626';

function setBadge(tabId, text, color) {
  try {
    chrome.action.setBadgeText({ tabId: tabId, text: text });
    if (text) {
      chrome.action.setBadgeBackgroundColor({ tabId: tabId, color: color });
      if (chrome.action.setBadgeTextColor) chrome.action.setBadgeTextColor({ tabId: tabId, color: '#ffffff' });
    }
  } catch (e) { /* tab already closed */ }
}

function flashWarning(tabId) {
  setBadge(tabId, '!', BADGE_WARN);
  setTimeout(function () { setBadge(tabId, '', BADGE_WARN); }, 2200);
}

chrome.commands.onCommand.addListener(function (command) {
  if (command !== 'toggle-mic') return;
  chrome.tabs.query({ active: true, lastFocusedWindow: true }, function (tabs) {
    var tab = tabs && tabs[0];
    if (!tab || tab.id == null) return;
    chrome.tabs.sendMessage(tab.id, { type: 'afruvo:toggle', source: 'shortcut' }, function (res) {
      // No answer = this page cannot host Afruvo (chrome:// page, Web Store, not reloaded yet) or no text box is focused.
      if (chrome.runtime.lastError || !res) flashWarning(tab.id);
    });
  });
});

chrome.runtime.onMessage.addListener(function (msg, sender) {
  if (!msg || msg.type !== 'afruvo:state' || !sender || !sender.tab) return;
  var on = msg.state === 'starting' || msg.state === 'listening';
  setBadge(sender.tab.id, on ? 'ON' : '', BADGE_ON);
});
