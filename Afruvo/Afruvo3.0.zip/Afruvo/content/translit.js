/*
 * Afruvo – Bengali script -> Roman ("Banglish") transliteration.
 *
 * Rule-based, fully offline. It converts recognised Bengali text into a
 * natural, phonetic Roman spelling (e.g. "আমি এখন যাচ্ছি" -> "ami ekhon jacchi").
 * Pronunciation-based: স/শ/ষ -> "sh" (বাসায় -> bashay), ছ -> "ch", চ্ছ -> "cch".
 * It uses heuristics for the inherent vowel ("o") and for conjuncts, so it is
 * a best-effort phonetic converter, not a perfect one. Latin text passes through.
 */
(function (root) {
  'use strict';

  var CONS = {
    'ক': 'k', 'খ': 'kh', 'গ': 'g', 'ঘ': 'gh', 'ঙ': 'ng',
    'চ': 'ch', 'ছ': 'ch', 'জ': 'j', 'ঝ': 'jh', 'ঞ': 'n',
    'ট': 't', 'ঠ': 'th', 'ড': 'd', 'ঢ': 'dh', 'ণ': 'n',
    'ত': 't', 'থ': 'th', 'দ': 'd', 'ধ': 'dh', 'ন': 'n',
    'প': 'p', 'ফ': 'f', 'ব': 'b', 'ভ': 'bh', 'ম': 'm',
    'য': 'j', 'র': 'r', 'ল': 'l', 'শ': 'sh', 'ষ': 'sh', 'স': 'sh', 'হ': 'h',
    'ড়': 'r', 'ঢ়': 'rh', 'য়': 'y', 'ৎ': 't'
  };
  var IND_VOWEL = {
    'অ': 'o', 'আ': 'a', 'ই': 'i', 'ঈ': 'i', 'উ': 'u', 'ঊ': 'u', 'ঋ': 'ri',
    'এ': 'e', 'ঐ': 'oi', 'ও': 'o', 'ঔ': 'ou'
  };
  var SIGN = {
    'া': 'a', 'ি': 'i', 'ী': 'i', 'ু': 'u', 'ূ': 'u', 'ৃ': 'ri',
    'ে': 'e', 'ৈ': 'oi', 'ো': 'o', 'ৌ': 'ou'
  };
  var DIGITS = { '০': '0', '১': '1', '২': '2', '৩': '3', '৪': '4', '৫': '5', '৬': '6', '৭': '7', '৮': '8', '৯': '9' };
  var HASANTA = '্';
  var NUKTA = '়';

  // Very common words whose final "o" is pronounced (rules cannot know this).
  var LEX = {
    'যাব': 'jabo', 'খাব': 'khabo', 'নেব': 'nebo', 'দেব': 'debo', 'পাব': 'pabo', 'হব': 'hobo',
    'করব': 'korbo', 'দেখব': 'dekhbo', 'বলব': 'bolbo', 'আসব': 'ashbo', 'থাকব': 'thakbo',
    'লিখব': 'likhbo', 'পড়ব': 'porbo', 'কত': 'koto', 'এত': 'eto', 'যত': 'joto', 'তত': 'toto',
    'ছিল': 'chilo', 'হল': 'holo', 'ভাল': 'bhalo', 'মত': 'moto', 'কখন': 'kokhon'
  };

  function isCons(c) { return Object.prototype.hasOwnProperty.call(CONS, c); }
  function isBengaliLetter(c) {
    var code = c.charCodeAt(0);
    return code >= 0x0980 && code <= 0x09FF && !DIGITS[c] && c !== '।' && c !== '॥';
  }

  function normalise(s) {
    return s
      .replace(/[\u200c\u200d]/g, '')
      // "ও" + ya-nukta (precomposed or decomposed) is the glide "w", as in খাওয়া / দেওয়া
      .replace(/\u0993(?:\u09DF|\u09AF\u09BC)/g, 'W');
  }

  function dbl(r) { return r.charAt(0) + r; }

  // true when "a" + "b" would read as one different letter (k+h, b+h, n+g ...)
  function makesDigraph(a, b) {
    if (!a || !b) return false;
    var pair = a.charAt(a.length - 1) + b.charAt(0);
    return ['kh', 'gh', 'ch', 'th', 'dh', 'ph', 'bh', 'jh', 'sh', 'ng'].indexOf(pair) !== -1;
  }

  // Render a consonant cluster (array of Bengali consonants) to Roman.
  function renderCluster(comps, initial) {
    var out = [];
    for (var i = 0; i < comps.length; i++) {
      var c = comps[i];
      var next = comps[i + 1];
      if (c === 'ক' && next === 'ষ') { out.push(i === 0 && initial ? 'kh' : 'kkh'); i++; continue; }
      if (c === 'জ' && next === 'ঞ') { out.push(i === 0 && initial ? 'gy' : 'gg'); i++; continue; }
      if (c === 'চ' && next === 'ছ') { out.push('cch'); i++; continue; }
      if (c === 'ঙ' && next === 'গ') { out.push('ng'); i++; continue; }
      if (c === 'স' && next && 'কটতথপফ'.indexOf(next) !== -1) { out.push('s'); continue; }
      if (i > 0 && out.length) {
        if (c === 'ব' && (comps[i - 1] === 'স' || comps[i - 1] === 'শ' || comps[i - 1] === 'ষ')) continue; // স্বপ্ন -> shopno
        if (c === 'য') { // ya-phola
          if (i === 1 && initial) out.push('y'); else out[out.length - 1] = dbl(out[out.length - 1]);
          continue;
        }
        if (c === 'ব') { // ba-phola
          if (i === 1 && initial) out.push('w'); else out[out.length - 1] = dbl(out[out.length - 1]);
          continue;
        }
        if (c === 'ম' && (comps[i - 1] === 'ত' || comps[i - 1] === 'দ')) { // ma-phola
          out[out.length - 1] = dbl(out[out.length - 1]);
          continue;
        }
      }
      out.push(c === 'W' ? 'w' : CONS[c]);
    }
    return out.join('');
  }

  // Break one Bengali word into syllable-like units.
  function parseWord(w) {
    var units = [];
    var i = 0;
    var n = w.length;
    while (i < n) {
      var c = w[i];
      if (c === 'W' || isCons(c) || (c === 'ড' || c === 'ঢ' || c === 'য')) {
        var comps = [];
        var noVowel = false;
        var cur = c;
        i++;
        if (w[i] === NUKTA && cur !== 'W') {
          cur = cur === 'ড' ? 'ড়' : cur === 'ঢ' ? 'ঢ়' : cur === 'য' ? 'য়' : cur;
          i++;
        }
        comps.push(cur);
        while (w[i] === HASANTA) {
          if (i + 1 < n && (isCons(w[i + 1]) || w[i + 1] === 'ড' || w[i + 1] === 'ঢ')) {
            var nx = w[i + 1];
            i += 2;
            if (w[i] === NUKTA) {
              nx = nx === 'ড' ? 'ড়' : nx === 'ঢ' ? 'ঢ়' : nx === 'য' ? 'য়' : nx;
              i++;
            }
            comps.push(nx);
          } else { i++; noVowel = true; break; }
        }
        if (comps[comps.length - 1] === 'ৎ') noVowel = true;
        var sign = null;
        if (SIGN[w[i]]) { sign = SIGN[w[i]]; i++; }
        units.push({ kind: 'c', comps: comps, sign: sign, noVowel: noVowel, coda: '' });
      } else if (IND_VOWEL[c]) {
        units.push({ kind: 'v', v: IND_VOWEL[c], coda: '' });
        i++;
      } else if (c === 'ং' || c === 'ঃ' || c === 'ঁ') {
        var last = units[units.length - 1];
        var coda = c === 'ং' ? 'ng' : c === 'ঃ' ? 'h' : '';
        if (last) last.coda += coda; else units.push({ kind: 'x', text: coda, coda: '' });
        i++;
      } else if (SIGN[c]) { // stray vowel sign
        units.push({ kind: 'x', text: SIGN[c], coda: '' });
        i++;
      } else {
        units.push({ kind: 'x', text: '', coda: '' });
        i++;
      }
    }
    return units;
  }

  function romanWord(w) {
    var units = parseWord(w);
    var lastIdx = units.length - 1;
    var out = '';
    var prevDeleted = false;
    for (var k = 0; k < units.length; k++) {
      var u = units[k];
      if (u.kind === 'v') { out += u.v + u.coda; prevDeleted = false; continue; }
      if (u.kind === 'x') { out += u.text + u.coda; prevDeleted = false; continue; }
      var initial = k === 0;
      var base = renderCluster(u.comps, initial);
      var vowel = '';
      var deleted = false;
      if (u.sign) {
        vowel = u.sign;
      } else if (u.noVowel) {
        deleted = true;
      } else {
        var conj = u.comps.length > 1;
        var hasCoda = u.coda !== '';
        var inh = (initial && conj && (u.comps[1] === 'য') && u.comps.length === 2) ? 'a' : 'o';
        if (k === lastIdx) {
          if (initial || conj || hasCoda) vowel = inh; else deleted = true;
        } else if (initial || hasCoda || prevDeleted) {
          vowel = inh;
        } else {
          var nxt = units[k + 1];
          var nextPronounced = false;
          if (nxt.kind === 'c' && nxt.comps.length === 1) {
            nextPronounced = !!nxt.sign || (!nxt.noVowel && (k + 1 !== lastIdx || nxt.coda !== ''));
          }
          var prevConj = units[k - 1].kind === 'c' && units[k - 1].comps.length > 1;
          if (nextPronounced && !conj && !prevConj) deleted = true; else vowel = inh;
          if (deleted && nxt.kind === 'c' && makesDigraph(base, renderCluster(nxt.comps, false))) { deleted = false; vowel = inh; }
        }
      }
      out += base + vowel + u.coda;
      prevDeleted = deleted;
    }
    return out;
  }

  function transliterate(text) {
    if (!text) return '';
    var s = normalise(String(text));
    var out = '';
    var i = 0;
    while (i < s.length) {
      var c = s[i];
      if (DIGITS[c]) { out += DIGITS[c]; i++; continue; }
      if (c === '।' || c === '॥') { out += '.'; i++; continue; }
      if (isBengaliLetter(c) || c === 'W') {
        var j = i;
        while (j < s.length && (isBengaliLetter(s[j]) || s[j] === 'W')) j++;
        var word = s.slice(i, j);
        out += Object.prototype.hasOwnProperty.call(LEX, word) ? LEX[word] : romanWord(word);
        i = j;
        continue;
      }
      out += c; i++;
    }
    return out.replace(/\s+/g, ' ').trim();
  }

  var api = { transliterate: transliterate };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.AfruvoTranslit = api;
})(typeof self !== 'undefined' ? self : this);
