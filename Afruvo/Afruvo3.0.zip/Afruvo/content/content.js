/*
 * Afruvo – content script.
 * Compact floating microphone, Web Speech recognition and text insertion.
 * Runs in every frame of http(s) pages. Nothing is stored or sent by this script;
 * speech is processed by the browser's own speech-recognition service.
 */
(function () {
  'use strict';

  if (window.__afruvoLoaded) return; // never initialise twice in the same frame
  window.__afruvoLoaded = true;

  var DEFAULTS = { mode: 'bangla', theme: 'light', micPos: null };   // 'bangla' | 'english' | 'banglish'
  var MODES = ['bangla', 'english', 'banglish'];
  var LANG = { bangla: 'bn-BD', english: 'en-US', banglish: 'bn-BD' }; // Banglish = Bangla speech -> Roman letters
  var MODE_NAME = { bangla: 'Bangla', english: 'English', banglish: 'Banglish' };
  var SIZE = 38;

  var SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  var settings = Object.assign({}, DEFAULTS);

  var field = null;          // current editable target
  var savedRange = null;     // last caret range for contenteditable targets
  var rec = null;            // active SpeechRecognition instance
  var wantListening = false; // user intent: keep listening until they stop
  var fatalError = false;
  var state = 'idle';        // idle | starting | listening | stopping | error
  var lastFinalIndex = -1;
  var lastFinalText = '';
  var lastFinalAt = 0;
  var noSpeechCount = 0;
  var restartTimes = [];
  var stopTimer = null;
  var chipTimer = null;
  var posTimer = null;
  var curX = 0, curY = 0;   // where the floating microphone currently is (viewport px)
  var drag = null;          // active drag gesture
  var suppressClick = false;
  var rafPending = false;
  var lastShortcutAt = 0;
  var lastMessage = '';

  /* ------------------------------------------------------------------ */
  /* Settings (chrome.storage.local is the single source of truth)       */
  /* ------------------------------------------------------------------ */
  function alive() {
    try { return !!(chrome.runtime && chrome.runtime.id); } catch (e) { return false; }
  }

  function sanitize(raw) {
    var s = Object.assign({}, DEFAULTS);
    if (!raw || typeof raw !== 'object') return s;
    if (MODES.indexOf(raw.mode) !== -1) s.mode = raw.mode;
    if (raw.theme === 'light' || raw.theme === 'dark') s.theme = raw.theme;
    var p = raw.micPos;
    if (p && typeof p === 'object' && isFinite(p.fx) && isFinite(p.fy)) {
      s.micPos = { fx: Math.max(0, Math.min(1, +p.fx)), fy: Math.max(0, Math.min(1, +p.fy)) };
    }
    return s;
  }

  // Always read the freshest value right before a session starts, so a mode change is never missed.
  function readSettings(cb) {
    if (!alive()) { cb(); return; }
    try {
      chrome.storage.local.get(DEFAULTS, function (res) {
        if (!chrome.runtime.lastError) settings = sanitize(res);
        applySettings();
        cb();
      });
    } catch (e) { cb(); }
  }

  function applySettings() {
    if (!ui.host) return;
    ui.host.setAttribute('data-theme', settings.theme);
    refreshLabels();
  }

  try {
    chrome.storage.onChanged.addListener(function (changes, area) {
      if (area !== 'local') return;
      var prev = settings;
      var merged = Object.assign({}, settings);
      Object.keys(changes).forEach(function (k) { merged[k] = changes[k].newValue; });
      settings = sanitize(merged);
      applySettings();
      if (prev.mode !== settings.mode && wantListening && rec) {
        // Restart so the recognizer picks up the new language; onend starts a fresh session.
        try { rec.abort(); } catch (e) { /* ignore */ }
      }
    });
  } catch (e) { /* extension context gone */ }

  /* ------------------------------------------------------------------ */
  /* Floating microphone (Shadow DOM, so page CSS cannot break it)       */
  /* ------------------------------------------------------------------ */
  var ui = { host: null, root: null, group: null, btn: null, chip: null };

  var CSS = [
    ':host{all:initial}',
    '*{box-sizing:border-box}',
    '.group{position:fixed;left:0;top:0;width:' + SIZE + 'px;height:' + SIZE + 'px;pointer-events:none;opacity:0;visibility:hidden;transition:opacity .15s ease}',
    '.group.show{opacity:.92;visibility:visible}',
    '.group.show:hover,.group.show.on{opacity:1}',
    '.mic{position:absolute;inset:0;width:' + SIZE + 'px;height:' + SIZE + 'px;border:0;padding:0;margin:0;border-radius:50%;cursor:grab;touch-action:none;user-select:none;-webkit-user-select:none;pointer-events:auto;',
    'background:linear-gradient(135deg,#3b82f6 0%,#7c3aed 100%);color:#fff;display:flex;align-items:center;justify-content:center;',
    'box-shadow:0 2px 8px rgba(76,29,149,.28),0 0 0 1px rgba(255,255,255,.35) inset;transition:transform .12s ease,box-shadow .12s ease;outline:none}',
    '.dragging .mic{cursor:grabbing;transform:scale(1.08);box-shadow:0 6px 16px rgba(76,29,149,.4)}',
    '.mic:hover{transform:scale(1.08)}',
    '.mic:active{transform:scale(.94)}',
    '.mic:focus-visible{box-shadow:0 0 0 2px #fff,0 0 0 4px #06b6d4}',
    '.mic svg{width:21px;height:21px;display:block}',
    '.ring{position:absolute;inset:-3px;border-radius:50%;border:2px solid #22c55e;opacity:0;pointer-events:none}',
    '.listening .mic{background:linear-gradient(135deg,#16a34a 0%,#0d9488 100%)}',
    '.listening .ring{animation:pulse 1.4s ease-out infinite}',
    '.starting .mic,.stopping .mic{background:linear-gradient(135deg,#f59e0b 0%,#7c3aed 100%)}',
    '.starting .ring,.stopping .ring{border-color:#f59e0b;border-top-color:transparent;opacity:1;animation:spin .8s linear infinite}',
    '.error .mic{background:linear-gradient(135deg,#ef4444 0%,#7c3aed 100%)}',
    '.chip{position:absolute;right:0;bottom:' + (SIZE + 6) + 'px;width:max-content;max-width:210px;padding:5px 9px;border-radius:8px;',
    'font:500 11.5px/1.3 system-ui,-apple-system,"Segoe UI","Noto Sans Bengali","Nirmala UI",sans-serif;',
    'background:#0f172a;color:#f1f5f9;box-shadow:0 4px 14px rgba(15,23,42,.3);pointer-events:none;opacity:0;transform:translateY(3px);',
    'transition:opacity .15s ease,transform .15s ease}',
    '.chip.on{opacity:1;transform:none}',
    '.chip.below{bottom:auto;top:' + (SIZE + 6) + 'px}',
    '.chip.left{right:auto;left:0}',
    '.chip.err{background:#7f1d1d;color:#fee2e2}',
    ':host([data-theme="dark"]) .chip:not(.err){background:#e2e8f0;color:#0f172a}',
    '@keyframes pulse{0%{transform:scale(.9);opacity:.9}100%{transform:scale(1.55);opacity:0}}',
    '@keyframes spin{to{transform:rotate(360deg)}}',
    '@media (prefers-reduced-motion:reduce){.listening .ring,.starting .ring,.stopping .ring{animation:none}.listening .ring{opacity:.8}}'
  ].join('');

  var MIC_SVG =
    '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true" focusable="false">' +
    '<rect x="8.5" y="2.5" width="7" height="12" rx="3.5" fill="#fff"/>' +
    '<path d="M5.5 11a6.5 6.5 0 0 0 13 0M12 17.5v3.5M8.5 21h7" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>' +
    '</svg>';

  function buildUI() {
    var existing = document.getElementById('afruvo-host');
    if (existing) existing.remove(); // never leave a duplicate behind
    var host = document.createElement('div');
    host.id = 'afruvo-host';
    host.setAttribute('data-theme', settings.theme);
    var root = host.attachShadow({ mode: 'open' });

    var style = document.createElement('style');
    style.textContent = CSS;
    var group = document.createElement('div');
    group.className = 'group';

    var ring = document.createElement('span'); ring.className = 'ring';
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'mic';
    btn.innerHTML = MIC_SVG;
    var chip = document.createElement('div');
    chip.className = 'chip';
    chip.setAttribute('role', 'status');
    chip.setAttribute('aria-live', 'polite');

    group.appendChild(ring);
    group.appendChild(btn);
    group.appendChild(chip);
    root.appendChild(style);
    root.appendChild(group);

    // Keep focus (and the caret) in the page field when the button is pressed.
    btn.addEventListener('mousedown', function (e) { e.preventDefault(); });
    btn.addEventListener('pointerdown', onDragStart);
    btn.addEventListener('pointermove', onDragMove);
    btn.addEventListener('pointerup', onDragEnd);
    btn.addEventListener('pointercancel', onDragEnd);
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      if (suppressClick) { suppressClick = false; return; } // this click ended a drag
      toggle('button');
    });

    (document.documentElement || document.body).appendChild(host);
    ui = { host: host, root: root, group: group, btn: btn, chip: chip };
    refreshLabels();
  }

  function refreshLabels() {
    if (!ui.btn) return;
    var on = state === 'starting' || state === 'listening';
    ui.btn.title = on ? 'Stop voice typing (Ctrl+Shift+Y)' : 'Voice typing \u00b7 ' + MODE_NAME[settings.mode] + ' (Ctrl+Shift+Y)';
    ui.btn.setAttribute('aria-label', on ? 'Stop voice typing' : 'Start voice typing in ' + MODE_NAME[settings.mode]);
    ui.btn.setAttribute('aria-pressed', on ? 'true' : 'false');
  }

  function setState(s) {
    state = s;
    if (ui.group) {
      ui.group.classList.remove('listening', 'starting', 'stopping', 'error', 'on');
      if (s !== 'idle') ui.group.classList.add(s, 'on');
      refreshLabels();
    }
    report();
  }

  // Short message: shown in a tiny chip next to the mic and forwarded to the popup.
  function say(text, opts) {
    opts = opts || {};
    lastMessage = text || '';
    clearTimeout(chipTimer);
    if (ui.chip) {
      if (!text) ui.chip.classList.remove('on');
      else {
        ui.chip.textContent = text;
        ui.chip.classList.toggle('err', !!opts.error);
        ui.chip.classList.add('on');
        chipTimer = setTimeout(function () {
          ui.chip.classList.remove('on');
          if (state === 'error') { lastMessage = ''; setState('idle'); }
        }, opts.ms || 4000);
      }
    }
    report();
  }

  function fail(text) {
    setState('error');
    say(text, { error: true, ms: 5000 });
  }

  function report() {
    if (!alive()) return;
    try {
      var p = chrome.runtime.sendMessage({ type: 'afruvo:state', state: state, message: lastMessage, mode: settings.mode });
      if (p && typeof p.catch === 'function') p.catch(function () { /* popup closed */ });
    } catch (e) { /* ignore */ }
  }

  /* ------------------------------------------------------------------ */
  /* Dragging the floating microphone                                    */
  /* ------------------------------------------------------------------ */
  function viewport() {
    return {
      w: document.documentElement.clientWidth || window.innerWidth,
      h: document.documentElement.clientHeight || window.innerHeight
    };
  }

  function placeAt(x, y) {
    curX = x; curY = y;
    ui.group.style.transform = 'translate(' + Math.round(x) + 'px,' + Math.round(y) + 'px)';
    ui.chip.classList.toggle('below', y < 60);
    ui.chip.classList.toggle('left', x < 230);
  }

  function onDragStart(e) {
    e.preventDefault(); // keep the caret/focus in the page field
    if (e.button !== undefined && e.button !== 0) return;
    drag = { sx: e.clientX, sy: e.clientY, ox: curX, oy: curY, moved: false, id: e.pointerId };
    try { ui.btn.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
  }

  function onDragMove(e) {
    if (!drag || e.pointerId !== drag.id) return;
    var dx = e.clientX - drag.sx, dy = e.clientY - drag.sy;
    if (!drag.moved) {
      if (Math.abs(dx) < 5 && Math.abs(dy) < 5) return; // a small wobble is still a click
      drag.moved = true;
      ui.group.classList.add('dragging');
      say('');
    }
    var vp = viewport();
    placeAt(Math.max(0, Math.min(vp.w - SIZE, drag.ox + dx)), Math.max(0, Math.min(vp.h - SIZE, drag.oy + dy)));
  }

  function onDragEnd(e) {
    if (!drag || (e && e.pointerId !== drag.id)) return;
    var d = drag; drag = null;
    try { ui.btn.releasePointerCapture(d.id); } catch (err) { /* ignore */ }
    ui.group.classList.remove('dragging');
    if (!d.moved) return;
    suppressClick = true;                       // the click that follows must not toggle the mic
    setTimeout(function () { suppressClick = false; }, 60);
    var vp = viewport();
    var pos = {
      fx: vp.w > SIZE ? curX / (vp.w - SIZE) : 0,
      fy: vp.h > SIZE ? curY / (vp.h - SIZE) : 0
    };
    settings.micPos = pos;
    if (alive()) { try { chrome.storage.local.set({ micPos: pos }); } catch (err) { /* ignore */ } }
  }

  /* ------------------------------------------------------------------ */
  /* Field detection and placement                                       */
  /* ------------------------------------------------------------------ */
  var TEXT_TYPES = { '': 1, text: 1, search: 1, email: 1, url: 1, tel: 1 };

  function deepActive() {
    var a = document.activeElement;
    while (a && a.shadowRoot && a.shadowRoot.activeElement) a = a.shadowRoot.activeElement;
    return a;
  }

  function getEditable(el) {
    if (!el || el.nodeType !== 1 || el === ui.host) return null;
    var tag = el.tagName;
    if (tag === 'INPUT') {
      var type = (el.getAttribute('type') || '').toLowerCase();
      if (!TEXT_TYPES[type] || el.readOnly || el.disabled) return null;
      return el;
    }
    if (tag === 'TEXTAREA') return (el.readOnly || el.disabled) ? null : el;
    if (el.isContentEditable) {
      var h = el;
      while (h.parentElement && h.parentElement.isContentEditable) h = h.parentElement;
      return h;
    }
    return null;
  }

  function hasLiveField() {
    return !!(field && field.isConnected && getEditable(deepActive()) === field);
  }

  function setField(el) {
    if (el === field) { showButton(); schedulePosition(); return; }
    if (wantListening) stopListening(); // never keep typing into a field the user left
    field = el;
    savedRange = null;
    say('');
    showButton();
    schedulePosition();
  }

  function showButton() {
    if (!ui.group || !field) return;
    ui.group.classList.add('show');
    if (!posTimer) posTimer = setInterval(schedulePosition, 600);
  }

  function hideButton() {
    if (!ui.group) return;
    ui.group.classList.remove('show');
    say('');
    clearInterval(posTimer);
    posTimer = null;
  }

  function schedulePosition() {
    if (rafPending) return;
    rafPending = true;
    requestAnimationFrame(function () { rafPending = false; position(); });
  }

  function position() {
    if (!ui.group) return;
    if (!field || !field.isConnected) {
      if (state === 'idle') hideButton();
      return;
    }
    var r = field.getBoundingClientRect();
    var vw = document.documentElement.clientWidth || window.innerWidth;
    var vh = document.documentElement.clientHeight || window.innerHeight;
    if (drag && drag.moved) return; // never fight the user's finger
    var userPos = settings.micPos;
    var offscreen = r.bottom < 0 || r.top > vh || r.right < 0 || r.left > vw;
    if (r.width < 4 || r.height < 4 || (offscreen && !userPos)) {
      ui.group.classList.remove('show'); // field hidden / scrolled out of view
      return;
    }
    ui.group.classList.add('show');
    if (userPos) {                      // the user chose a spot: keep it there
      placeAt(Math.round(userPos.fx * Math.max(0, vw - SIZE)), Math.round(userPos.fy * Math.max(0, vh - SIZE)));
      return;
    }
    var gap = 5, x, y;
    if (r.right + gap + SIZE + 4 <= vw) x = r.right + gap;     // beside the field, outside it
    else x = r.right - SIZE - gap;                              // no room: inside the right edge
    y = r.height > 100 ? r.top + gap : r.top + (r.height - SIZE) / 2;
    x = Math.max(4, Math.min(vw - SIZE - 4, x));
    y = Math.max(4, Math.min(vh - SIZE - 4, y));
    placeAt(x, y);
  }

  document.addEventListener('focusin', function () {
    var el = getEditable(deepActive());
    if (el) setField(el);
  }, true);

  document.addEventListener('focusout', function () {
    setTimeout(function () {
      if (state !== 'idle') return;
      if (!getEditable(deepActive())) hideButton();
    }, 200);
  }, true);

  window.addEventListener('scroll', schedulePosition, true);
  window.addEventListener('resize', schedulePosition);

  document.addEventListener('selectionchange', function () {
    if (!field || field.tagName === 'INPUT' || field.tagName === 'TEXTAREA') return;
    var root = field.getRootNode && field.getRootNode();
    var sel = (root && root.getSelection) ? root.getSelection() : window.getSelection();
    if (sel && sel.rangeCount && field.contains(sel.getRangeAt(0).startContainer)) {
      savedRange = sel.getRangeAt(0).cloneRange();
    }
  });

  /* ------------------------------------------------------------------ */
  /* Text insertion                                                      */
  /* ------------------------------------------------------------------ */
  function needsLeadingSpace(prevChar, text) {
    if (!prevChar || /[\s\u00a0(\[{"'\u201c\u2018]/.test(prevChar)) return false;
    if (/^[.,!?;:\u0964)\]}]/.test(text)) return false;
    return true;
  }

  function insertText(el, text) {
    if (!el || !el.isConnected || !text) return false;
    try { el.focus({ preventScroll: true }); } catch (e) { /* ignore */ }

    if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
      var val = el.value;
      var start = null, end = null;
      try { start = el.selectionStart; end = el.selectionEnd; } catch (e) { /* e.g. type=email */ }
      if (start == null) { start = end = val.length; }
      var ins = (needsLeadingSpace(start > 0 ? val.charAt(start - 1) : '', text) ? ' ' : '') + text;
      var ok = false;
      try { ok = document.execCommand('insertText', false, ins); } catch (e) { ok = false; }
      if (!ok || el.value === val) {
        // Fallback: native value setter (works with React/Vue controlled inputs) + events.
        var proto = el.tagName === 'INPUT' ? HTMLInputElement.prototype : HTMLTextAreaElement.prototype;
        var setter = Object.getOwnPropertyDescriptor(proto, 'value');
        var next = val.slice(0, start) + ins + val.slice(end);
        if (setter && setter.set) setter.set.call(el, next); else el.value = next;
        try { el.setSelectionRange(start + ins.length, start + ins.length); } catch (e) { /* ignore */ }
        el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: ins }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
      }
      return true;
    }

    // contenteditable
    var root = el.getRootNode && el.getRootNode();
    var sel = (root && root.getSelection) ? root.getSelection() : window.getSelection();
    var range = sel && sel.rangeCount ? sel.getRangeAt(0) : null;
    if (!range || !el.contains(range.startContainer)) {
      if (savedRange && el.contains(savedRange.startContainer)) {
        range = savedRange;
      } else {
        range = document.createRange();
        range.selectNodeContents(el);
        range.collapse(false);
      }
      sel.removeAllRanges();
      sel.addRange(range);
    }
    var prev = '';
    if (range.startContainer.nodeType === 3 && range.startOffset > 0) {
      prev = range.startContainer.data.charAt(range.startOffset - 1);
    }
    var ins2 = (needsLeadingSpace(prev, text) ? ' ' : '') + text;
    var ok2 = false;
    try { ok2 = document.execCommand('insertText', false, ins2); } catch (e) { ok2 = false; }
    if (!ok2) {
      range.deleteContents();
      var node = document.createTextNode(ins2);
      range.insertNode(node);
      range.setStartAfter(node);
      range.collapse(true);
      sel.removeAllRanges();
      sel.addRange(range);
      el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: ins2 }));
    }
    return true;
  }

  /* ------------------------------------------------------------------ */
  /* Speech recognition                                                  */
  /* ------------------------------------------------------------------ */
  // Bangla  : speak Bangla  -> Bengali script (as recognised)
  // English : speak English -> English text
  // Banglish: speak Bangla  -> recognised as Bangla, then converted to Roman letters
  function convert(text) {
    if (settings.mode === 'banglish' && window.AfruvoTranslit) return window.AfruvoTranslit.transliterate(text);
    return text;
  }

  function describeError(code) {
    switch (code) {
      case 'not-allowed':
      case 'service-not-allowed':
        return 'Microphone blocked. Allow it via the lock icon in the address bar.';
      case 'audio-capture': return 'No microphone found.';
      case 'network': return 'No internet connection for speech service.';
      case 'language-not-supported': return 'This language is not supported.';
      default: return 'Speech error (' + code + ').';
    }
  }

  function createRecognition() {
    var r = new SR();
    r.continuous = true;
    r.interimResults = true;
    r.maxAlternatives = 1;
    r.lang = LANG[settings.mode] || 'bn-BD';
    lastFinalIndex = -1;

    r.onstart = function () {
      if (rec !== r) return;
      setState('listening');
      say('');
    };

    r.onresult = function (e) {
      if (rec !== r) return;
      noSpeechCount = 0;
      for (var i = e.resultIndex; i < e.results.length; i++) {
        var res = e.results[i];
        if (!res.isFinal) continue;       // only finished phrases are typed
        if (i <= lastFinalIndex) continue; // already inserted
        lastFinalIndex = i;
        handleFinal((res[0] && res[0].transcript) || '');
      }
    };

    r.onerror = function (e) {
      if (rec !== r) return;
      var code = e && e.error;
      if (code === 'aborted') return;
      if (code === 'no-speech') {
        noSpeechCount++;
        if (noSpeechCount >= 3) {
          fatalError = true;
          wantListening = false;
          say('No speech detected. Microphone turned off.', { error: true, ms: 4000 });
        }
        return;
      }
      fatalError = true;
      wantListening = false;
      clearTimeout(stopTimer);
      detach(r);
      try { r.abort(); } catch (err) { /* already stopped */ }
      rec = null; // release the session so the user can try again right away
      fail(describeError(code));
    };

    r.onend = function () {
      if (rec !== r) return;
      detach(r);
      rec = null;
      clearTimeout(stopTimer);
      if (wantListening && !fatalError && field && field.isConnected) {
        var now = Date.now();
        restartTimes = restartTimes.filter(function (t) { return now - t < 5000; });
        if (restartTimes.length >= 4) {
          wantListening = false;
          fail('Speech recognition keeps stopping. Try again.');
          return;
        }
        restartTimes.push(now);
        setTimeout(function () { if (wantListening && !rec) startSession(); }, 200);
        return;
      }
      wantListening = false;
      if (state !== 'error') setState('idle');
    };
    return r;
  }

  function detach(r) {
    r.onstart = r.onresult = r.onerror = r.onend = null;
  }

  function handleFinal(raw) {
    var text = (raw || '').trim();
    if (!text) return;
    var now = Date.now();
    if (text === lastFinalText && now - lastFinalAt < 400) return; // duplicate guard
    lastFinalText = text;
    lastFinalAt = now;
    var out = convert(text);
    if (out) insertText(field, out);
  }

  function startSession() {
    try {
      rec = createRecognition();
      rec.start();
    } catch (e) {
      rec = null;
      wantListening = false;
      fail('Could not start the microphone. Try again.');
    }
  }

  function startListening() {
    if (!alive()) { fail('Afruvo was updated. Reload this page.'); return false; }
    if (!SR) { fail('Speech recognition is not available here.'); return false; }
    if (!field || !field.isConnected) { say('Click a text box first.', { error: true, ms: 3000 }); return false; }
    if (!window.isSecureContext) { fail('Needs a secure (https) page.'); return false; }
    if (rec || wantListening) return true;
    wantListening = true;
    fatalError = false;
    noSpeechCount = 0;
    restartTimes = [];
    setState('starting');
    readSettings(function () {          // pick up the latest language right before starting
      if (wantListening && !rec) startSession();
    });
    return true;
  }

  function stopListening() {
    wantListening = false;
    var r = rec;
    if (!r) { setState('idle'); say(''); return; }
    setState('stopping');
    try { r.stop(); } catch (e) { /* ignore */ }
    clearTimeout(stopTimer);
    stopTimer = setTimeout(function () { // never get stuck waiting for onend
      if (rec === r) {
        try { r.abort(); } catch (e) { /* ignore */ }
        detach(r);
        rec = null;
        setState('idle');
        say('');
      }
    }, 2500);
  }

  // source: 'button' | 'popup' | 'shortcut' | 'key'
  function toggle(source) {
    if (source === 'shortcut' || source === 'key') {
      // The Chrome command and the in-page key handler can both fire for one key press.
      var now = Date.now();
      if (now - lastShortcutAt < 250) return true;
      lastShortcutAt = now;
    }
    if (wantListening || rec) { stopListening(); return true; }
    return startListening();
  }

  /* ------------------------------------------------------------------ */
  /* Messages from the popup / service worker, and the in-page shortcut  */
  /* ------------------------------------------------------------------ */
  try {
    chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
      if (!msg || typeof msg.type !== 'string') return false;
      var busy = wantListening || !!rec;

      if (msg.type === 'afruvo:getState') {
        var snapshot = function () {
          return { state: state, message: lastMessage, busy: busy, hasField: hasLiveField(), supported: !!SR, mode: settings.mode };
        };
        if (busy || hasLiveField()) { sendResponse(snapshot()); return false; }
        if (window === window.top) {
          // Top frame answers last, so a frame that owns the focused field wins.
          setTimeout(function () { try { sendResponse(snapshot()); } catch (e) { /* gone */ } }, 80);
          return true;
        }
        return false;
      }

      if (msg.type === 'afruvo:toggle') {
        if (!busy && !hasLiveField()) {
          if (msg.source === 'shortcut' && window === window.top) {
            // Nobody owns a text field: tell the user instead of failing silently.
            setTimeout(function () {
              if (state === 'idle' && !hasLiveField()) say('Click a text box first.', { error: true, ms: 2500 });
            }, 120);
          }
          return false; // another frame (or nobody) owns the field
        }
        var ok = toggle(msg.source || 'popup');
        sendResponse({ ok: ok, state: state, message: lastMessage });
        return false;
      }
      return false;
    });
  } catch (e) { /* ignore */ }

  // Fallback for when Chrome does not assign the command (shortcut conflict): works while the page has focus.
  var IS_MAC = /Mac|iPhone|iPad/.test(navigator.platform || '');
  document.addEventListener('keydown', function (e) {
    var mod = IS_MAC ? e.metaKey : e.ctrlKey;
    if (!mod || !e.shiftKey || e.altKey || (IS_MAC ? e.ctrlKey : e.metaKey)) return;
    if (e.code !== 'KeyY' && String(e.key).toLowerCase() !== 'y') return;
    if (!(wantListening || rec) && !hasLiveField()) return;
    e.preventDefault();
    e.stopPropagation();
    toggle('key');
  }, true);

  window.addEventListener('pagehide', function () {
    wantListening = false;
    if (rec) { try { rec.abort(); } catch (e) { /* ignore */ } }
  });

  /* ------------------------------------------------------------------ */
  /* Init                                                                */
  /* ------------------------------------------------------------------ */
  buildUI();
  readSettings(function () {});
  var initial = getEditable(deepActive());
  if (initial) setField(initial);
})();
