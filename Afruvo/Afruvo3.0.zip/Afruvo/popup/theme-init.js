/* Runs before first paint so the popup never flashes the wrong theme.
   chrome.storage.local remains the source of truth; localStorage is only a fast cache. */
(function () {
  try {
    var t = localStorage.getItem('afruvo-theme');
    if (t !== 'light' && t !== 'dark') {
      t = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    }
    document.documentElement.setAttribute('data-theme', t);
  } catch (e) { /* default stays light */ }
})();
