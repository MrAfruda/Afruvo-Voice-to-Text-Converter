/* Afruvo popup – language, theme (both saved), microphone on/off and status. */
(function () {
  'use strict';

  var DEFAULTS = { mode: 'bangla', theme: 'light' };
  var MODES = ['bangla', 'english', 'banglish'];
  var SAMPLES = {
    bangla:   { cap: 'Speak Bangla \u2192 Bengali script', ex: '\u0986\u09AE\u09BF \u098F\u0996\u09A8 \u09AC\u09BE\u09B8\u09BE\u09AF\u09BC \u09AF\u09BE\u099A\u09CD\u099B\u09BF\u0964', lang: 'bn' },
    english:  { cap: 'Speak English \u2192 English text', ex: 'I am going home now.', lang: 'en' },
    banglish: { cap: 'Speak Bangla \u2192 Roman letters', ex: 'ami ekhon bashay jacchi', lang: 'en' }
  };
  var systemTheme = (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) ? 'dark' : 'light';
  var settings = Object.assign({}, DEFAULTS, { theme: systemTheme });
  var activeTabId = null;

  var $ = function (id) { return document.getElementById(id); };
  var el = {
    themeToggle: $('themeToggle'), micBtn: $('micBtn'), statusDot: $('statusDot'), statusText: $('statusText'),
    sample: $('sample'), kMod: $('kMod')
  };

  function sanitize(raw) {
    var s = Object.assign({}, DEFAULTS, { theme: systemTheme });
    if (!raw || typeof raw !== 'object') return s;
    if (MODES.indexOf(raw.mode) !== -1) s.mode = raw.mode;
    if (raw.theme === 'light' || raw.theme === 'dark') s.theme = raw.theme;
    return s;
  }

  function save(patch) {
    Object.assign(settings, patch);
    chrome.storage.local.set(patch);
  }

  /* ---------- theme ---------- */
  function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    try { localStorage.setItem('afruvo-theme', theme); } catch (e) { /* ignore */ }
    var next = theme === 'dark' ? 'light' : 'dark';
    el.themeToggle.setAttribute('aria-label', 'Switch to ' + next + ' theme');
    el.themeToggle.title = 'Switch to ' + next + ' theme';
  }

  /* ---------- language ---------- */
  function renderMode() {
    var radios = document.querySelectorAll('input[name="mode"]');
    for (var i = 0; i < radios.length; i++) radios[i].checked = radios[i].value === settings.mode;
    var s = SAMPLES[settings.mode];
    el.sample.textContent = '';
    var cap = document.createElement('span'); cap.className = 'cap'; cap.textContent = s.cap;
    var ex = document.createElement('span'); ex.className = 'ex'; ex.textContent = s.ex; ex.lang = s.lang;
    el.sample.appendChild(cap);
    el.sample.appendChild(ex);
  }

  /* ---------- status ---------- */
  // state: idle | starting | listening | stopping | error ; kind: '' | 'warn' | 'error'
  function showStatus(state, message, kind) {
    var text = message;
    if (!text) {
      text = state === 'listening' ? 'Listening\u2026'
        : state === 'starting' ? 'Starting\u2026'
        : state === 'stopping' ? 'Stopping\u2026'
        : state === 'error' ? 'Something went wrong' : 'Microphone off';
    }
    var on = state === 'listening';
    var busy = state === 'starting' || state === 'stopping';
    var pressed = state === 'listening' || state === 'starting';
    el.statusDot.setAttribute('data-state', state === 'idle' ? 'off' : state);
    el.statusText.textContent = text;
    el.statusText.parentNode.className = 'status' + (kind ? ' ' + kind : state === 'error' ? ' error' : '');
    el.micBtn.classList.toggle('on', on);
    el.micBtn.classList.toggle('busy', busy);
    el.micBtn.setAttribute('aria-pressed', pressed ? 'true' : 'false');
    var label = pressed ? 'Turn microphone off' : 'Turn microphone on';
    el.micBtn.setAttribute('aria-label', label);
    el.micBtn.title = label;
  }

  function withActiveTab(cb) {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      var tab = tabs && tabs[0];
      activeTabId = tab ? tab.id : null;
      cb(activeTabId);
    });
  }

  function refreshState() {
    withActiveTab(function (id) {
      if (id == null) return;
      chrome.tabs.sendMessage(id, { type: 'afruvo:getState' }, function (res) {
        if (chrome.runtime.lastError || !res) {
          showStatus('idle', 'Not available on this page', 'warn');
          return;
        }
        if (!res.supported) { showStatus('error', 'Speech recognition is not supported here'); return; }
        showStatus(res.state, res.state === 'idle' ? '' : res.message);
      });
    });
  }

  function toggleMic() {
    el.micBtn.disabled = true;
    setTimeout(function () { el.micBtn.disabled = false; }, 400);
    withActiveTab(function (id) {
      if (id == null) return;
      chrome.tabs.sendMessage(id, { type: 'afruvo:toggle', source: 'popup' }, function (res) {
        if (chrome.runtime.lastError || !res) {
          showStatus('idle', 'Click a text box on the page first', 'warn');
          return;
        }
        if (res.ok === false) { showStatus(res.state === 'error' ? 'error' : 'idle', res.message || '', res.state === 'error' ? '' : 'warn'); return; }
        showStatus(res.state, res.state === 'error' ? res.message : '');
      });
    });
  }

  /* ---------- init ---------- */
  function init() {
    if (/Mac|iPhone|iPad/.test(navigator.platform || '')) el.kMod.textContent = '\u2318';

    chrome.storage.local.get(['mode', 'theme'], function (stored) {
      settings = sanitize(stored);
      if (!stored || !stored.theme) chrome.storage.local.set({ theme: settings.theme }); // first run: remember system theme
      applyTheme(settings.theme);
      renderMode();
      showStatus('idle', '');
      refreshState();
    });

    el.themeToggle.addEventListener('click', function () {
      var next = settings.theme === 'dark' ? 'light' : 'dark';
      save({ theme: next });
      applyTheme(next);
    });

    var radios = document.querySelectorAll('input[name="mode"]');
    for (var i = 0; i < radios.length; i++) {
      radios[i].addEventListener('change', function (e) {
        if (e.target.checked && MODES.indexOf(e.target.value) !== -1) { save({ mode: e.target.value }); renderMode(); }
      });
    }

    el.micBtn.addEventListener('click', toggleMic);

    chrome.runtime.onMessage.addListener(function (msg, sender) {
      if (!msg || msg.type !== 'afruvo:state') return;
      if (sender && sender.tab && activeTabId != null && sender.tab.id !== activeTabId) return;
      showStatus(msg.state, msg.state === 'error' ? msg.message : '');
    });

    chrome.storage.onChanged.addListener(function (changes, area) {
      if (area !== 'local') return;
      var patch = {};
      Object.keys(changes).forEach(function (k) { patch[k] = changes[k].newValue; });
      settings = sanitize(Object.assign({}, settings, patch));
      applyTheme(settings.theme);
      renderMode();
    });
  }

  init();
})();
